module com.baeldung.service {
	requires com.baeldung.core;
}
